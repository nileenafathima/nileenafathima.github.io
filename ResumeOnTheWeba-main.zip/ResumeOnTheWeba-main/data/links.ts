const links = {
  instagram: "https://pillai.xyz/instagram",
  linkedin: "https://pillai.xyz/linkedin",
  twitter: "https://pillai.xyz/twitter",
  github: "https://pillai.xyz/github",
  dribbble: "https://pillai.xyz/dribbble",
  dev: "https://pillai.xyz/dev",
  facebook: "https://pillai.xyz/facebook",
  resume: "https://pillai.xyz/resume-pdf",
  repository: "https://github.com/AmruthPillai/ResumeOnTheWeb",
};

export default links;
